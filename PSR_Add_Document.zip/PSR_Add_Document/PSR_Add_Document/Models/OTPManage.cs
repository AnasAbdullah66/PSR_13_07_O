﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PSR_Add_Document.Models
{
    public class OTPManage
    {
        [Key]
        public int OTPId { get; set; }
        public string? OTP { get; set; }
        public int CustomerId { get; set; }
        public DateTime? OtpTime { get; set; }
        public string MobileNumber { get; set; }

        //
        public virtual Customer Customer { get; set; }
    }
}
